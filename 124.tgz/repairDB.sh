#!/bin/bash

# ============================================
# Configuration Parameters (Modify as needed)
# ============================================

# Working directory, default is current directory
WORK_DIR="${WORK_DIR:-.}"

# MySQL connection configuration
MYSQL_HOST="${MYSQL_HOST:-127.0.0.1}"
MYSQL_USER="${MYSQL_USER:-checksum}"
MYSQL_PASSWORD="${MYSQL_PASSWORD:-checksum}"
MYSQL_PORT="${MYSQL_PORT:-3406}"
MYSQL_DATABASE="${MYSQL_DATABASE:-sbtest}"

# Concurrency level, default is 1 (serial execution)
CONCURRENCY="${CONCURRENCY:-4}"

# Log file
LOG_FILE="${LOG_FILE:-repairDB.log}"

# ============================================
# Function Definitions
# ============================================

# Print help information
print_help() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --work-dir DIR       Working directory, default is current directory"
    echo "  --host HOST          MySQL host address, default is localhost"
    echo "  --user USER          MySQL username, default is root"
    echo "  --password PASS      MySQL password"
    echo "  --port PORT          MySQL port, default is 3306"
    echo "  --database DB        Database name"
    echo "  --concurrency N      Concurrency level, default is 1"
    echo "  --log-file FILE      Log file, default is repairDB.log"
    echo "  --help               Show this help message"
    echo ""
    echo "You can also set these parameters via environment variables, for example:"
    echo "  WORK_DIR=/path MYSQL_HOST=localhost $0"
}

# Parse command line arguments
parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --work-dir)
                WORK_DIR="$2"
                shift 2
                ;;
            --host)
                MYSQL_HOST="$2"
                shift 2
                ;;
            --user)
                MYSQL_USER="$2"
                shift 2
                ;;
            --password)
                MYSQL_PASSWORD="$2"
                shift 2
                ;;
            --port)
                MYSQL_PORT="$2"
                shift 2
                ;;
            --database)
                MYSQL_DATABASE="$2"
                shift 2
                ;;
            --concurrency)
                CONCURRENCY="$2"
                shift 2
                ;;
            --log-file)
                LOG_FILE="$2"
                shift 2
                ;;
            --help)
                print_help
                exit 0
                ;;
            *)
                echo "Unknown option: $1"
                print_help
                exit 1
                ;;
        esac
    done
}

# Check required parameters
check_parameters() {
    local missing_params=()
    
    if [[ -z "$MYSQL_HOST" ]]; then
        missing_params+=("MySQL host address")
    fi
    
    if [[ -z "$MYSQL_USER" ]]; then
        missing_params+=("MySQL username")
    fi
    
    if [[ -z "$MYSQL_DATABASE" ]]; then
        missing_params+=("Database name")
    fi
    
    if [[ ${#missing_params[@]} -gt 0 ]]; then
        echo "Error: The following parameters are not set:"
        for param in "${missing_params[@]}"; do
            echo "  - $param"
        done
        echo ""
        echo "Please set these parameters via command line arguments or environment variables"
        exit 1
    fi
    
    # Check if working directory exists
    if [[ ! -d "$WORK_DIR" ]]; then
        echo "Error: Working directory does not exist: $WORK_DIR"
        exit 1
    fi
    
    # Check if fixsql directory exists
    local fixsql_dir="$WORK_DIR/fixsql"
    if [[ ! -d "$fixsql_dir" ]]; then
        echo "Error: fixsql directory does not exist: $fixsql_dir"
        exit 1
    fi
}

# Build MySQL client command
build_mysql_command() {
    local password_param=""
    if [[ -n "$MYSQL_PASSWORD" ]]; then
        password_param="-p${MYSQL_PASSWORD}"
    fi
    
    echo "mysql -h${MYSQL_HOST} -u${MYSQL_USER} ${password_param} -P${MYSQL_PORT} -A -f ${MYSQL_DATABASE}"
}

# Execute SQL file and log results
execute_sql_file() {
    local sql_file="$1"
    local mysql_cmd="$2"
    
    echo "===========================================" >> "$LOG_FILE"
    echo "Start execution: $(date)" >> "$LOG_FILE"
    echo "SQL file: $sql_file" >> "$LOG_FILE"
    echo "===========================================" >> "$LOG_FILE"
    
    # Execute SQL file
    $mysql_cmd < "$sql_file" >> "$LOG_FILE" 2>&1
    
    local exit_code=$?
    
    echo "" >> "$LOG_FILE"
    echo "Execution completed: $(date)" >> "$LOG_FILE"
    echo "Exit code: $exit_code" >> "$LOG_FILE"
    echo "" >> "$LOG_FILE"
    
    return $exit_code
}

# Print configuration information
print_config() {
    echo "==========================================="
    echo "SQL Execution Script Configuration"
    echo "==========================================="
    echo "Working directory: $WORK_DIR"
    echo "MySQL host:        $MYSQL_HOST"
    echo "MySQL user:        $MYSQL_USER"
    echo "MySQL port:        $MYSQL_PORT"
    echo "Database name:     $MYSQL_DATABASE"
    echo "Concurrency level: $CONCURRENCY"
    echo "Log file:          $LOG_FILE"
    echo "==========================================="
    echo ""
}

# ============================================
# Main Program Logic
# ============================================

main() {
    # Parse command line arguments
    parse_arguments "$@"
    
    # Check required parameters
    check_parameters
    
    # Print configuration information
    print_config
    
    # Change to working directory
    cd "$WORK_DIR" || exit 1
    
    # Build MySQL command
    local mysql_cmd
    mysql_cmd=$(build_mysql_command)
    
    # Clear or create log file
    > "$LOG_FILE"
    
    # fixsql directory path
    local fixsql_dir="./fixsql"
    
    echo "Start processing fixsql directory: $fixsql_dir" | tee -a "$LOG_FILE"
    echo ""
    
    # Find all .sql files
    local sql_files=()
    while IFS= read -r -d '' file; do
        sql_files+=("$file")
    done < <(find "$fixsql_dir" -name "*.sql" -type f -print0)
    
    # Check if any SQL files exist
    if [[ ${#sql_files[@]} -eq 0 ]]; then
        echo "No .sql files found in $fixsql_dir directory" | tee -a "$LOG_FILE"
        exit 1
    fi
    
    # Check if there is only a single datafix.sql file
    if [[ ${#sql_files[@]} -eq 1 ]] && [[ "${sql_files[0]}" == */datafix.sql ]]; then
        echo "Found single datafix.sql file, executing directly..." | tee -a "$LOG_FILE"
        execute_sql_file "${sql_files[0]}" "$mysql_cmd"
        local exit_code=$?
        
        if [[ $exit_code -eq 0 ]]; then
            echo "datafix.sql executed successfully" | tee -a "$LOG_FILE"
        else
            echo "datafix.sql execution failed, exit code: $exit_code" | tee -a "$LOG_FILE"
        fi
        
        exit $exit_code
    fi
    
    # Separate DELETE files from other files
    local delete_files=()
    local other_files=()
    
    for sql_file in "${sql_files[@]}"; do
        if [[ "$sql_file" == *-DELETE.sql ]]; then
            delete_files+=("$sql_file")
        elif [[ "$sql_file" != */datafix.sql ]]; then
            other_files+=("$sql_file")
        fi
    done
    
    echo "Found ${#delete_files[@]} DELETE files, ${#other_files[@]} other SQL files" | tee -a "$LOG_FILE"
    echo ""
    
    # First, execute all DELETE files (sequential execution)
    if [[ ${#delete_files[@]} -gt 0 ]]; then
        echo "Start executing DELETE files..." | tee -a "$LOG_FILE"
        
        # Sort DELETE files
        IFS=$'\n' sorted_delete_files=($(sort <<<"${delete_files[*]}"))
        unset IFS
        
        for delete_file in "${sorted_delete_files[@]}"; do
            echo "Executing: $delete_file" | tee -a "$LOG_FILE"
            execute_sql_file "$delete_file" "$mysql_cmd"
            
            local exit_code=$?
            if [[ $exit_code -ne 0 ]]; then
                echo "Warning: $delete_file execution failed, exit code: $exit_code" | tee -a "$LOG_FILE"
            fi
        done
        
        echo "DELETE files execution completed" | tee -a "$LOG_FILE"
        echo ""
    fi
    
    # Execute other SQL files in parallel
    if [[ ${#other_files[@]} -gt 0 ]]; then
        echo "Start parallel execution of other SQL files, concurrency level: $CONCURRENCY" | tee -a "$LOG_FILE"
        
        # Sort files
        IFS=$'\n' sorted_other_files=($(sort <<<"${other_files[*]}"))
        unset IFS
        
        # Define parallel execution function
        execute_parallel() {
            local file="$1"
            echo "Start executing: $file" | tee -a "$LOG_FILE"
            execute_sql_file "$file" "$mysql_cmd"
            local exit_code=$?
            
            if [[ $exit_code -eq 0 ]]; then
                echo "Completed: $file" | tee -a "$LOG_FILE"
            else
                echo "Failed: $file (exit code: $exit_code)" | tee -a "$LOG_FILE"
            fi
        }
        
        # Export functions for use in subshell
        export -f execute_sql_file
        export -f execute_parallel
        export mysql_cmd
        export LOG_FILE
        
        # Use xargs for parallel execution
        printf "%s\n" "${sorted_other_files[@]}" | xargs -I {} -P "$CONCURRENCY" bash -c 'execute_parallel "$@"' _ {}
        
        echo "Other SQL files execution completed" | tee -a "$LOG_FILE"
    fi
    
    echo ""
    echo "All SQL files execution completed" | tee -a "$LOG_FILE"
    echo "Detailed log available at: $LOG_FILE"
}

# Execute main function
main "$@"
